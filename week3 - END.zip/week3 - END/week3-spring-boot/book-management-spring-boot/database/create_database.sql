CREATE DATABASE IF NOT EXISTS book_management_db;
USE book_management_db;
