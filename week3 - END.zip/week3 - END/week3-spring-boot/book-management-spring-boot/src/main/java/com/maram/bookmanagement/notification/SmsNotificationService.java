package com.maram.bookmanagement.notification;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

@Service("smsNotificationService")
@Primary
public class SmsNotificationService implements NotificationService {

    @Override
    public void sendNotification(String message) {
        System.out.println("SMS notification: " + message);
    }
}
