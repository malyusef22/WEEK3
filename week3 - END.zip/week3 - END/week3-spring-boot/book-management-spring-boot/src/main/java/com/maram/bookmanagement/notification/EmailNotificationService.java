package com.maram.bookmanagement.notification;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

@Service("emailNotificationService")
@Scope("prototype")
public class EmailNotificationService implements NotificationService {

    public EmailNotificationService() {
        System.out.println("EmailNotificationService bean created");
    }

    @Override
    public void sendNotification(String message) {
        System.out.println("EMAIL notification: " + message);
    }
}
