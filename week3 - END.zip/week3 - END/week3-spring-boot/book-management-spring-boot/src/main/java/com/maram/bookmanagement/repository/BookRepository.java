package com.maram.bookmanagement.repository;

import com.maram.bookmanagement.entity.Book;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface BookRepository extends JpaRepository<Book, Long> {

    List<Book> findByCategoryIgnoreCase(String category);

    boolean existsByCodeIgnoreCase(String code);
}
