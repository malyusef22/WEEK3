package com.maram.bookmanagement.notification;

public interface NotificationService {
    void sendNotification(String message);
}
