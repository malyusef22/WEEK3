package com.maram.bookmanagement.service;

import com.maram.bookmanagement.entity.Book;
import com.maram.bookmanagement.exception.BookNotFoundException;
import com.maram.bookmanagement.notification.NotificationService;
import com.maram.bookmanagement.repository.BookRepository;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@Service
@Transactional
public class BookServiceImpl implements BookService {

    private final BookRepository bookRepository;
    private final NotificationService notificationService;

    public BookServiceImpl(
            BookRepository bookRepository,
            @Qualifier("emailNotificationService") NotificationService notificationService) {
        this.bookRepository = bookRepository;
        this.notificationService = notificationService;
    }

    @Override
    @Transactional(readOnly = true)
    public List<Book> findAll(Sort sort) {
        return bookRepository.findAll(sort);
    }

    @Override
    @Transactional(readOnly = true)
    public Book findById(Long id) {
        return bookRepository.findById(id)
                .orElseThrow(() -> new BookNotFoundException(id));
    }

    @Override
    @Transactional(readOnly = true)
    public List<Book> findByCategory(String category) {
        return bookRepository.findByCategoryIgnoreCase(category);
    }

    @Override
    public Book create(Book book) {
        book.setId(null);
        Book savedBook = bookRepository.save(book);
        notificationService.sendNotification("Book created: " + savedBook.getTitle());
        return savedBook;
    }

    @Override
    public Book update(Long id, Book book) {
        Book existing = findById(id);

        existing.setTitle(book.getTitle());
        existing.setCategory(book.getCategory());
        existing.setPrice(book.getPrice());
        existing.setPageCount(book.getPageCount());
        existing.setLevel(book.getLevel());
        existing.setActive(book.isActive());
        existing.setCode(book.getCode());

        Book savedBook = bookRepository.save(existing);
        notificationService.sendNotification("Book updated: " + savedBook.getTitle());
        return savedBook;
    }

    @Override
    public Book partialUpdate(Long id, Map<String, Object> updates) {
        Book existing = findById(id);

        updates.forEach((field, value) -> {
            switch (field) {
                case "title" -> existing.setTitle(String.valueOf(value));
                case "category" -> existing.setCategory(String.valueOf(value));
                case "price" -> existing.setPrice(new BigDecimal(String.valueOf(value)));
                case "pageCount" -> existing.setPageCount(Integer.valueOf(String.valueOf(value)));
                case "level" -> existing.setLevel(String.valueOf(value));
                case "active" -> existing.setActive(Boolean.parseBoolean(String.valueOf(value)));
                case "code" -> existing.setCode(String.valueOf(value));
                case "id" -> throw new IllegalArgumentException("The id field cannot be changed");
                default -> throw new IllegalArgumentException("Unknown field: " + field);
            }
        });

        Book savedBook = bookRepository.save(existing);
        notificationService.sendNotification("Book partially updated: " + savedBook.getTitle());
        return savedBook;
    }

    @Override
    public void delete(Long id) {
        Book existing = findById(id);
        bookRepository.delete(existing);
        notificationService.sendNotification("Book deleted: " + existing.getTitle());
    }
}
