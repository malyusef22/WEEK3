package com.maram.bookmanagement.config;

import com.maram.bookmanagement.entity.Book;
import com.maram.bookmanagement.repository.BookRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.math.BigDecimal;

@Configuration
public class DataInitializer {

    @Bean
    CommandLineRunner initializeData(
            JdbcTemplate jdbcTemplate,
            PasswordEncoder passwordEncoder,
            BookRepository bookRepository) {

        return args -> {
            createUserIfMissing(jdbcTemplate, passwordEncoder,
                    "employee", "employee123", "ROLE_EMPLOYEE");
            createUserIfMissing(jdbcTemplate, passwordEncoder,
                    "manager", "manager123", "ROLE_MANAGER");
            createUserIfMissing(jdbcTemplate, passwordEncoder,
                    "admin", "admin123", "ROLE_ADMIN");

            if (bookRepository.count() == 0) {
                bookRepository.save(new Book(
                        "Spring Boot Basics",
                        "Programming",
                        new BigDecimal("120.00"),
                        350,
                        "BEGINNER",
                        true,
                        "SPR-101"));

                bookRepository.save(new Book(
                        "Database Fundamentals",
                        "Database",
                        new BigDecimal("95.50"),
                        280,
                        "BEGINNER",
                        true,
                        "DBS-102"));
            }
        };
    }

    private void createUserIfMissing(
            JdbcTemplate jdbcTemplate,
            PasswordEncoder passwordEncoder,
            String username,
            String rawPassword,
            String authority) {

        Integer count = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM users WHERE username = ?",
                Integer.class,
                username);

        if (count != null && count == 0) {
            jdbcTemplate.update(
                    "INSERT INTO users (username, password, enabled) VALUES (?, ?, ?)",
                    username,
                    passwordEncoder.encode(rawPassword),
                    true);

            jdbcTemplate.update(
                    "INSERT INTO authorities (username, authority) VALUES (?, ?)",
                    username,
                    authority);
        }
    }
}
