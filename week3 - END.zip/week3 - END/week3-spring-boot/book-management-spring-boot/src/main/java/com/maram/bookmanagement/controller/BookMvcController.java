package com.maram.bookmanagement.controller;

import com.maram.bookmanagement.entity.Book;
import com.maram.bookmanagement.service.BookService;
import jakarta.validation.Valid;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/books")
public class BookMvcController {

    private final BookService bookService;

    public BookMvcController(BookService bookService) {
        this.bookService = bookService;
    }

    @InitBinder
    public void initializeBinder(WebDataBinder binder) {
        binder.registerCustomEditor(String.class, new StringTrimmerEditor(true));
    }

    @GetMapping
    public String showBooks(Model model) {
        model.addAttribute("books", bookService.findAll(Sort.by("id").ascending()));
        return "books/list";
    }

    @GetMapping("/new")
    public String showAddForm(Model model) {
        model.addAttribute("book", new Book());
        addFormOptions(model);
        return "books/form";
    }

    @PostMapping
    public String saveBook(
            @Valid @ModelAttribute("book") Book book,
            BindingResult bindingResult,
            Model model) {

        if (bindingResult.hasErrors()) {
            addFormOptions(model);
            return "books/form";
        }

        bookService.create(book);
        return "redirect:/books";
    }

    private void addFormOptions(Model model) {
        model.addAttribute("categories",
                List.of("Programming", "Database", "Web", "Security", "Other"));
        model.addAttribute("levels",
                List.of("BEGINNER", "INTERMEDIATE", "ADVANCED"));
    }
}
