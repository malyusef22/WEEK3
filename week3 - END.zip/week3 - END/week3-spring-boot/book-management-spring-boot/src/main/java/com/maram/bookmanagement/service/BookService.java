package com.maram.bookmanagement.service;

import com.maram.bookmanagement.entity.Book;
import org.springframework.data.domain.Sort;

import java.util.List;
import java.util.Map;

public interface BookService {

    List<Book> findAll(Sort sort);

    Book findById(Long id);

    List<Book> findByCategory(String category);

    Book create(Book book);

    Book update(Long id, Book book);

    Book partialUpdate(Long id, Map<String, Object> updates);

    void delete(Long id);
}
