package com.maram.bookmanagement.entity;

import com.maram.bookmanagement.validation.ValidBookCode;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;

import java.math.BigDecimal;

@Entity
@Table(name = "books")
public class Book {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Title is required")
    @Size(max = 150, message = "Title must not exceed 150 characters")
    @Column(nullable = false, length = 150)
    private String title;

    @NotBlank(message = "Category is required")
    @Column(nullable = false, length = 80)
    private String category;

    @NotNull(message = "Price is required")
    @DecimalMin(value = "0.0", inclusive = true, message = "Price must be zero or greater")
    @Digits(integer = 8, fraction = 2, message = "Price must have at most 8 integer digits and 2 decimal places")
    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal price;

    @NotNull(message = "Page count is required")
    @Min(value = 1, message = "Page count must be at least 1")
    @Max(value = 5000, message = "Page count must not exceed 5000")
    @Column(nullable = false)
    private Integer pageCount;

    @NotBlank(message = "Level is required")
    @Pattern(regexp = "BEGINNER|INTERMEDIATE|ADVANCED",
             message = "Level must be BEGINNER, INTERMEDIATE, or ADVANCED")
    @Column(nullable = false, length = 20)
    private String level;

    @Column(nullable = false)
    private boolean active = true;

    @NotBlank(message = "Code is required")
    @ValidBookCode
    @Column(nullable = false, unique = true, length = 20)
    private String code;

    public Book() {
    }

    public Book(String title, String category, BigDecimal price, Integer pageCount,
                String level, boolean active, String code) {
        this.title = title;
        this.category = category;
        this.price = price;
        this.pageCount = pageCount;
        this.level = level;
        this.active = active;
        this.code = code;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }
    public BigDecimal getPrice() { return price; }
    public void setPrice(BigDecimal price) { this.price = price; }
    public Integer getPageCount() { return pageCount; }
    public void setPageCount(Integer pageCount) { this.pageCount = pageCount; }
    public String getLevel() { return level; }
    public void setLevel(String level) { this.level = level; }
    public boolean isActive() { return active; }
    public void setActive(boolean active) { this.active = active; }
    public String getCode() { return code; }
    public void setCode(String code) { this.code = code; }
}
