package com.maram.bookmanagement.validation;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class BookCodeValidator implements ConstraintValidator<ValidBookCode, String> {

    private static final String CODE_PATTERN = "^[A-Z]{3}-\\d{3}$";

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        return value == null || value.matches(CODE_PATTERN);
    }
}
